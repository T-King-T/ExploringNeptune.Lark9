Welcome to LARK
>>>>>>>the Linux Activity to Reinforce Knowledge

Name of Game: Exploring Neptune

Developed by: Trevor Kingery


Narrative:
Welcome to the U.S.S. Neptune (Unix. Space. Ship), namesake of the Roman god of the sea. Because long before exploring the infinite regions of space, our ancestors risked their lives on primitive wooden ships to explore the Earth's oceans.  
You have managed to attain an invitation to board the ship for it's final voyage into space. However, there have many rumors surrounding the ship and its many passengers that have journeyed on this ship have seemed to disappear without a trace by the time the ship makes it's return. Your job is to explore the ship and uncover as many clues as possible that relate to the rumors and disappearances.


Instructions:
Ensure the console is in fullscreen mode


'ls' is used to view available options in an area

'cd <name>' can be used to move to BLUE names.

'. <name>' can be used to interact with GREEN names

'cat <name>' can be used to view white names surraounded in * *

using 'Commands' will pull up a list of command options



*When entering an area, interact with WHITE then GREEN names, before moving to a new area.*



When you are ready to board, enter the command '. StartMenu' to begin.


